import axios from 'axios';
import { SchedulingData, Feedback } from '../types';

const API_BASE_URL = 'http://localhost:5000';

export const calculateSchedule = async (dailyOrderVolume: number): Promise<SchedulingData> => {
  const response = await axios.post(`${API_BASE_URL}/calculate`, { dailyOrderVolume });
  return response.data;
};

export const getFeedback = async (): Promise<Feedback[]> => {
  const response = await axios.get(`${API_BASE_URL}/api/feedback`);
  return response.data;
};

export const downloadReport = async (type: string): Promise<Blob> => {
  const response = await axios.get(`${API_BASE_URL}/api/download/${type}`, {
    responseType: 'blob'
  });
  return response.data;
};