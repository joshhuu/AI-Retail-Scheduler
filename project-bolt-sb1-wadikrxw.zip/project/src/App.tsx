import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import OrderInput from './components/OrderInput';
import SchedulingResults from './components/SchedulingResults';
import FeedbackOverview from './components/FeedbackOverview';
import DownloadSection from './components/DownloadSection';
import { calculateSchedule, getFeedback } from './api';
import { SchedulingData, Feedback } from './types';

function App() {
  const [schedulingData, setSchedulingData] = useState<SchedulingData | null>(null);
  const [feedback, setFeedback] = useState<Feedback[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadFeedback = async () => {
      try {
        const data = await getFeedback();
        setFeedback(data);
      } catch (err) {
        setError('Failed to load feedback data');
      }
    };

    loadFeedback();
  }, []);

  const handleOrderSubmit = async (volume: number) => {
    setIsLoading(true);
    setError(null);
    try {
      const data = await calculateSchedule(volume);
      setSchedulingData(data);
    } catch (err) {
      setError('Failed to calculate schedule');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <div className="space-y-8">
          <OrderInput onSubmit={handleOrderSubmit} isLoading={isLoading} />
          
          {error && (
            <div className="bg-red-600 text-white p-4 rounded-lg">
              {error}
            </div>
          )}
          
          {schedulingData && (
            <SchedulingResults data={schedulingData} />
          )}
          
          <FeedbackOverview feedback={feedback} />
          
          <DownloadSection />
        </div>
      </main>
    </div>
  );
}

export default App;