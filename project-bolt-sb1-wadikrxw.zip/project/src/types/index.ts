export interface Employee {
  Employee_ID: string;
  Target_Laddoos?: number;
  Assigned_Laddoos?: number;
  Adjusted_Assigned_Laddoos?: number;
  Target_Jalebis?: number;
  Assigned_Jalebis?: number;
  Adjusted_Assigned_Jalebis?: number;
  Target_Packaged?: number;
  Assigned_Packaged?: number;
  Adjusted_Assigned_Packaged?: number;
  Target_Sales?: number;
  Assigned_Sales?: number;
  Adjusted_Assigned_Sales?: number;
}

export interface Feedback {
  timestamp: string;
  emoji: string;
  feedback: string;
}

export interface SchedulingData {
  sweetsMakers: Employee[];
  sweetsPackagers: Employee[];
  retailers: Employee[];
}