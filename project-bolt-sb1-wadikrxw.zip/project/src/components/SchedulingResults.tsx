import React from 'react';
import { Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';
import { Employee } from '../types';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

interface SchedulingResultsProps {
  data: {
    sweetsMakers: Employee[];
    sweetsPackagers: Employee[];
    retailers: Employee[];
  };
}

const SchedulingResults: React.FC<SchedulingResultsProps> = ({ data }) => {
  const renderEmployeeTable = (employees: Employee[], title: string) => (
    <div className="mb-8">
      <h3 className="text-lg font-semibold text-white mb-4">{title}</h3>
      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left text-gray-300">
          <thead className="text-xs uppercase bg-gray-700">
            <tr>
              <th className="px-6 py-3">Employee ID</th>
              <th className="px-6 py-3">Target</th>
              <th className="px-6 py-3">Assigned</th>
              <th className="px-6 py-3">AI Adjusted</th>
            </tr>
          </thead>
          <tbody>
            {employees.map((employee) => (
              <tr key={employee.Employee_ID} className="border-b border-gray-700">
                <td className="px-6 py-4">{employee.Employee_ID}</td>
                <td className="px-6 py-4">{employee.Target_Laddoos || employee.Target_Packaged || employee.Target_Sales}</td>
                <td className="px-6 py-4">{employee.Assigned_Laddoos || employee.Assigned_Packaged || employee.Assigned_Sales}</td>
                <td className="px-6 py-4">{employee.Adjusted_Assigned_Laddoos || employee.Adjusted_Assigned_Packaged || employee.Adjusted_Assigned_Sales}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderChart = (employees: Employee[], title: string) => {
    const chartData = {
      labels: employees.map(e => e.Employee_ID),
      datasets: [
        {
          label: 'Normal Assignment',
          data: employees.map(e => e.Assigned_Laddoos || e.Assigned_Packaged || e.Assigned_Sales),
          backgroundColor: 'rgba(53, 162, 235, 0.5)',
        },
        {
          label: 'AI Adjusted',
          data: employees.map(e => e.Adjusted_Assigned_Laddoos || e.Adjusted_Assigned_Packaged || e.Adjusted_Assigned_Sales),
          backgroundColor: 'rgba(75, 192, 192, 0.5)',
        },
      ],
    };

    return (
      <div className="mb-8">
        <h3 className="text-lg font-semibold text-white mb-4">{title} - Comparison Chart</h3>
        <Bar
          data={chartData}
          options={{
            responsive: true,
            plugins: {
              legend: {
                position: 'top' as const,
                labels: {
                  color: 'white',
                },
              },
            },
            scales: {
              y: {
                ticks: { color: 'white' },
                grid: { color: 'rgba(255, 255, 255, 0.1)' },
              },
              x: {
                ticks: { color: 'white' },
                grid: { color: 'rgba(255, 255, 255, 0.1)' },
              },
            },
          }}
        />
      </div>
    );
  };

  return (
    <div className="bg-gray-800 p-6 rounded-lg">
      <h2 className="text-2xl font-bold text-white mb-6">Scheduling Results</h2>
      
      {renderEmployeeTable(data.sweetsMakers, 'Sweets Makers')}
      {renderChart(data.sweetsMakers, 'Sweets Makers')}
      
      {renderEmployeeTable(data.sweetsPackagers, 'Sweets Packagers')}
      {renderChart(data.sweetsPackagers, 'Sweets Packagers')}
      
      {renderEmployeeTable(data.retailers, 'Retailers')}
      {renderChart(data.retailers, 'Retailers')}
    </div>
  );
};

export default SchedulingResults;