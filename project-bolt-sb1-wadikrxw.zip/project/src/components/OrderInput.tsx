import React, { useState } from 'react';
import { Calculator } from 'lucide-react';

interface OrderInputProps {
  onSubmit: (volume: number) => void;
  isLoading: boolean;
}

const OrderInput: React.FC<OrderInputProps> = ({ onSubmit, isLoading }) => {
  const [volume, setVolume] = useState<string>('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numVolume = parseInt(volume);
    if (!isNaN(numVolume) && numVolume > 0) {
      onSubmit(numVolume);
    }
  };

  return (
    <div className="bg-gray-800 p-6 rounded-lg">
      <h2 className="text-xl font-semibold text-white mb-4">Daily Order Volume</h2>
      <form onSubmit={handleSubmit} className="flex gap-4">
        <input
          type="number"
          value={volume}
          onChange={(e) => setVolume(e.target.value)}
          placeholder="Enter daily order volume"
          className="flex-1 px-4 py-2 rounded bg-gray-700 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
          min="1"
        />
        <button
          type="submit"
          disabled={isLoading}
          className="flex items-center gap-2 px-6 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50"
        >
          <Calculator className="w-5 h-5" />
          {isLoading ? 'Calculating...' : 'Calculate'}
        </button>
      </form>
    </div>
  );
};

export default OrderInput;