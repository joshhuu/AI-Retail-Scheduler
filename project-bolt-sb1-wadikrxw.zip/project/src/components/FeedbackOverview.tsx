import React from 'react';
import { Feedback } from '../types';
import { format } from 'date-fns';
import { MessageSquare } from 'lucide-react';

interface FeedbackOverviewProps {
  feedback: Feedback[];
}

const FeedbackOverview: React.FC<FeedbackOverviewProps> = ({ feedback }) => {
  const getEmojiCount = () => {
    return feedback.reduce((acc, curr) => {
      acc[curr.emoji] = (acc[curr.emoji] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);
  };

  const emojiCounts = getEmojiCount();

  return (
    <div className="bg-gray-800 p-6 rounded-lg">
      <div className="flex items-center gap-3 mb-6">
        <MessageSquare className="w-6 h-6 text-blue-500" />
        <h2 className="text-2xl font-bold text-white">Employee Feedback</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-gray-700 p-4 rounded-lg">
          <h3 className="text-lg font-semibold text-white mb-4">Emoji Distribution</h3>
          <div className="flex justify-around text-center">
            {Object.entries(emojiCounts).map(([emoji, count]) => (
              <div key={emoji} className="flex flex-col items-center">
                <span className="text-2xl mb-2">{emoji}</span>
                <span className="text-white">{count}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-gray-700 p-4 rounded-lg">
          <h3 className="text-lg font-semibold text-white mb-4">Recent Feedback</h3>
          <div className="space-y-4">
            {feedback.slice(0, 5).map((item, index) => (
              <div key={index} className="border-b border-gray-600 pb-3 last:border-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-xl">{item.emoji}</span>
                  <span className="text-gray-400 text-sm">
                    {format(new Date(item.timestamp), 'MMM d, yyyy HH:mm')}
                  </span>
                </div>
                <p className="text-gray-300">{item.feedback}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default FeedbackOverview;