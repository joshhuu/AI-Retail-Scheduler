import React from 'react';
import { Download } from 'lucide-react';
import { downloadReport } from '../api';

const DownloadSection: React.FC = () => {
  const handleDownload = async (type: string) => {
    try {
      const blob = await downloadReport(type);
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${type}-report.csv`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      console.error('Download failed:', error);
    }
  };

  return (
    <div className="bg-gray-800 p-6 rounded-lg">
      <h2 className="text-xl font-semibold text-white mb-4">Download Reports</h2>
      <div className="flex flex-wrap gap-4">
        <button
          onClick={() => handleDownload('schedule')}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        >
          <Download className="w-5 h-5" />
          Schedule Data
        </button>
        <button
          onClick={() => handleDownload('performance')}
          className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700"
        >
          <Download className="w-5 h-5" />
          Performance Stats
        </button>
        <button
          onClick={() => handleDownload('feedback')}
          className="flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded hover:bg-purple-700"
        >
          <Download className="w-5 h-5" />
          Feedback Data
        </button>
      </div>
    </div>
  );
};

export default DownloadSection;